#!/usr/bin/env python3 
import rospy 
import turtle

def draw_spirally_squares(): 
    t = turtle.Turtle() 
    t.shape("turtle") 
    t.speed(1)
    side_length = 100  # Set the length of the triangle sides 
    
    for i in range(3):  # Draw a triangle
        t.forward(side_length)
        t.left(120)  # Angle for an equilateral triangle 
    
    turtle.mainloop()

if __name__ == '__main__':
    rospy.init_node('turtle_spirally_squares')
    try:
        draw_spirally_squares()
    except rospy.ROSInterruptException:
        pass

