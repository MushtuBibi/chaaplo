#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist

def publish_commands():
    rospy.init_node('turtlebot_publisher', anonymous=True)
    publisher = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
    rate = rospy.Rate(1)  # 1 Hz

    while not rospy.is_shutdown():
        try:
            # Get user input for controlling the turtle
            linear_x = float(input("Enter linear velocity (x): "))
            angular_z = float(input("Enter angular velocity (z): "))

            twist = Twist()
            twist.linear.x = linear_x
            twist.angular.z = angular_z

            publisher.publish(twist)
            rospy.loginfo(f'Published: linear.x = {linear_x}, angular.z = {angular_z}')

            rate.sleep()
        except rospy.ROSInterruptException:
            break
        except ValueError:
            rospy.logwarn("Invalid input. Please enter numeric values.")

if __name__ == '__main__':
    try:
        publish_commands()
    except rospy.ROSInterruptException:
        pass

