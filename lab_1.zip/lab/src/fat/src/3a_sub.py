#!/usr/bin/env python3

import rospy
from turtlesim.msg import Pose

def pose_callback(msg):
    rospy.loginfo(f'Received Pose: x = {msg.x}, y = {msg.y}, theta = {msg.theta}')

def main():
    rospy.init_node('turtlebot_subscriber', anonymous=True)
    rospy.Subscriber('/turtle1/pose', Pose, pose_callback)

    rospy.spin()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass

