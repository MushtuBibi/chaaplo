#!/usr/bin/env python3
from fat.srv import ConvertMetersToFeet, ConvertMetersToFeetRequest, ConvertMetersToFeetResponse
import rospy
import numpy as np

_CONVERSION_FACTOR_METRES_TO_FEET = 3.28

def process_service_request(req):
    res = ConvertMetersToFeetResponse()
    if req.distance_metres < 0:
        res.success = False
        res.distance_feet = -np.Inf
    else:
        res.distance_feet = _CONVERSION_FACTOR_METRES_TO_FEET * req.distance_metres
        res.success = True
    return res

def metres_to_feet_server():
    rospy.init_node('metres_to_feet_server', anonymous=False)
    service = rospy.Service('metres_to_feet', ConvertMetersToFeet, process_service_request)
    rospy.loginfo('Convert metres to feet service is now available.')
    rospy.spin()

if __name__ == "__main__":
    metres_to_feet_server()

