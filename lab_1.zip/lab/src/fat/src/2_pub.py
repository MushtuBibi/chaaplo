#!/usr/bin/env python3
import rospy
from std_msgs.msg import Float64

def talker():
    pub = rospy.Publisher('chatter', Float64, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        a = float(input("enter a"))
        b = float(input("enter b"))
        c = float(input("enter c"))
        Sum= a+b+c
        sq = Sum*Sum
        #rospy.loginfo(f"output=  {sq}")
        pub.publish(sq)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
